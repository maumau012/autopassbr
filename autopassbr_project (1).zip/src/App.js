import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import './App.css';

function App() {
  const randomPixKey = 'ed390d7c-5732-4e98-b0fb-87880975947d';
  const pricePerTicket = 3;
  const minTickets = 5;

  const [tickets, setTickets] = useState(0);
  const [showQRCode, setShowQRCode] = useState(false);

  const handleConfirmPurchase = () => {
    if (tickets >= minTickets) {
      setShowQRCode(true);
    } else {
      alert(`Você precisa comprar no mínimo ${minTickets} passes.`);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-md mx-auto bg-white p-4 rounded-2xl shadow-lg">
        <h1 className="text-3xl font-bold text-blue-600 mb-4 text-center">AutopassBR - Passagem de Trem</h1>
        
        {!showQRCode ? (
          <div className="text-center">
            <p className="text-lg text-gray-700">Escolha a quantidade de passes (mínimo {minTickets}):</p>
            
            <div className="mt-4">
              <input
                type="number"
                value={tickets}
                onChange={(e) => setTickets(e.target.value)}
                min={minTickets}
                className="border border-gray-300 rounded-lg p-2 w-32 text-center"
              />
            </div>
            
            <p className="mt-4 text-gray-700">Preço total: R$ {tickets * pricePerTicket}</p>

            <button
              onClick={handleConfirmPurchase}
              className="bg-green-500 text-white px-4 py-2 rounded-full mt-4"
            >
              Confirmar Compra
            </button>
          </div>
        ) : (
          <div className="text-center">
            <p className="text-lg text-gray-700 mb-4">Obrigado pela sua compra! Escaneie o QR Code para pagar:</p>
            <div className="mt-4">
              <QRCodeSVG value={randomPixKey} size={150} />
            </div>
            <p className="mt-2 text-gray-500">Chave Pix: {randomPixKey}</p>
            <p className="mt-4 text-gray-500">Valor total: R$ {tickets * pricePerTicket}</p>
            <button
              onClick={() => setShowQRCode(false)}
              className="bg-red-500 text-white px-4 py-2 rounded-full mt-4"
            >
              Voltar
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
