
import { QRCodeSVG } from 'qrcode.react';
import './App.css';

function App() {
  const randomPixKey = 'ed390d7c-5732-4e98-b0fb-87880975947d';
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-md mx-auto bg-white p-4 rounded-2xl shadow-lg">
        <h1 className="text-3xl font-bold text-blue-600 mb-4 text-center">AutopassBR - Passagem de Trem</h1>
        <div className="text-center">
          <p className="text-lg text-gray-700">Obrigado pela sua compra! Escaneie o QR code abaixo para receber seu passe:</p>
          <div className="mt-4">
            <QRCodeSVG value={randomPixKey} size={150} />
          </div>
          <p className="mt-2 text-gray-500">Chave Pix: {randomPixKey}</p>
          <button className="bg-green-500 text-white px-4 py-2 rounded-full mt-4">Compre já seu passe</button>
        </div>
      </div>
    </div>
  );
}

export default App;
